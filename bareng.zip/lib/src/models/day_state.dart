enum DayState { idle, opened, deposited, missed }
