enum RobotMood { happy, neutral, waiting, disappointed, proud }
